from django.contrib import admin
from .models import *
from Carts.models import *

admin.site.register(Book)
admin.site.register(Genre)


class BookAdmin(admin.ModelAdmin):
    list_display = ['title', 'isbn', 'price']
    class Meta:
        model = Book

# class CartAdmin(admin.ModelAdmin):
#     class Meta:
#         model = Cart


admin.site.register(Cart)
admin.site.register(CartItem)
