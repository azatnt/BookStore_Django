from django.db import models
from django.utils.text import slugify
from django.shortcuts import reverse, redirect
from time import time

def gen_slug(s):
    new_slug = slugify(s)
    return new_slug + '-' + str(int(time()))


class Book(models.Model):
    title = models.CharField(max_length=50, db_index=True)
    slug = models.SlugField(unique=True, blank=True)
    body = models.TextField(blank=True, max_length=1000)
    isbn = models.IntegerField()
    date_pub = models.DateTimeField(auto_now_add=True)
    price = models.IntegerField()
    image = models.ImageField(upload_to='book-image', blank=True, default='smth')
    genre = models.ManyToManyField('Genre', blank=True, related_name='books')
    active = models.BooleanField(default=True)

    def get_absolute_url(self):
        return reverse('book_detail_url', kwargs={'slug':self.slug})

    def save(self, *args, **kwargs):
        if not self.id:
            self.slug = gen_slug(self.title)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title

    class Meta:
        ordering = ['-date_pub']


class Genre(models.Model):
    title = models.CharField(max_length=50, db_index=True)
    slug = models.SlugField(unique=True, blank=True)

    def get_absolute_url(self):
        return reverse('genre_detail_url', kwargs={'slug':self.slug})

    def save(self, *args, **kwargs):
        if not self.id:
            self.slug = gen_slug(self.title)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title


    class Meta:
        ordering = ['title']


class User(models.Model):
    username = models.CharField(max_length=50)
    password1 = models.CharField(max_length=50)
    password2 = models.CharField(max_length=50)
