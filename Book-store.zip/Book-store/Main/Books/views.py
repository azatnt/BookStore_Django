from django.shortcuts import render
from django.http import HttpResponse
from .models import *
from django.db.models import Q
from .forms import *
from django.views.generic import View
from django.core.paginator import Paginator



def pagination(request):
    return HttpResponse(request, 'books/pagination.html')


def index(request):
    return HttpResponse("<h3>Page not found, ERROR 404</h3>")


def book_list(request):
    search_query = request.GET.get('search', '')

    if search_query:
        books = Book.objects.filter(Q(title__icontains=search_query) | Q(body__icontains=search_query))
        genre = Book.objects.filter(Q(title__icontains=search_query) | Q(body__icontains=search_query))
    else:
        books = Book.objects.all()
        genre = Genre.objects.all()

    paginator = Paginator(books, 9)
    page_num = request.GET.get('page', 1)
    page = paginator.get_page(page_num)



    is_paginated = page.has_other_pages()

    if page.has_previous():
        prev_url = '?page={}'.format(page.previous_page_number())

    else:
        prev_url = 'pagination'


    if page.has_next():
        next_url = '?page={}'.format(page.next_page_number())

    else:
        next_url = 'pagination'

    
    

    context = {
        'books':books,
        'genre':genre,
        'page_object': page,
        'is_paginated': is_paginated,
        'next_url': next_url,
        'prev_url': prev_url
    }


    return render(request, 'books/index.html', context=context)




def book_detail(request, slug):
    book = Book.objects.get(slug__iexact=slug)
    return render(request, 'books/book_detail.html', context={'book':book})



def genre_detail(request, slug):
    genre = Genre.objects.get(slug__iexact=slug)
    genres = Genre.objects.all()
    context = {
        'genre':genre,
        'genres':genres
    }
    return render(request, 'books/genre_detail.html', context=context)



def genre_list(request):
    genre = Genre.objects.all()
    return render(request, 'books/genre.html', context={'genre':genre})
