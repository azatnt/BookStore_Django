from django.urls import path
from .views import *
from Carts.views import *
from orders.views import *



urlpatterns = [
    path('', book_list, name = 'book_list_url'),
    path('book/genre', genre_list, name = 'genre_list_url'),
    path('pagination/', index, name = 'pagination'),
    path('book/<str:slug>', book_detail, name = 'book_detail_url'),
    path('book/<str:slug>/cart', update_cart, name = 'update_cart_url'),
    path('book/genre/<str:slug>', genre_detail, name = 'genre_detail_url'),
    path('cart/<str:id>\d+', remove_from_cart, name = 'remove_cart_url'),
    path('cart/<str:slug>', update_cart, name = 'update_cart_url'),
    path('cart', view, name = 'cart_url'),
    path('checkout', checkout, name = 'checkout_url'),
    path('orders', orders, name='user_orders_urls'),


]
