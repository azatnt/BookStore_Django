from django import forms
from .models import *


class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['title', 'slug', 'body', 'isbn', 'price', 'image']

        widgets = {
            'title': forms.TextInput(),
            'slug': forms.TextInput(),
            'body': forms.TextInput(),
            'isbn': forms.IntegerField(),
            'price': forms.IntegerField(),
            'image': forms.ImageField(),
        }
