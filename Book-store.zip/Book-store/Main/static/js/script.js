$(document).ready(function(){
  var form = $('#form_buying_product');
  console.log('Hello world');
});
