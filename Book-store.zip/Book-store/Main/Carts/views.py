from django.shortcuts import render, HttpResponseRedirect
from django.urls import reverse
from .models import *
from Books.models import *

def view(request):
    try:
        the_id = request.session['cart_id']
        cart = Cart.objects.get(id = the_id)

    except:
        the_id = None

    if the_id:
        new_total = 0
        for item in cart.cartitem_set.all():
            # print(item.price)
            # print(item.price)
            line_total = float(item.product.price) * item.quantity
            new_total += line_total
        cart.total = new_total
        cart.save()
        request.session['items_total'] = cart.cartitem_set.count()
        context = {'cart':cart}
    else:
        empty_message = "Your cart is empty, please keep shopping"
        context = {'empty':True, 'empty_message': empty_message}

    return render(request, 'carts/view.html', context)


def remove_from_cart(request, id):
    try:
        the_id = request.session['cart_id']
        cart = Cart.objects.get(id = the_id)
    except:
        return HttpResponseRedirect(reverse('cart_url'))

    cartitem = CartItem.objects.get(id=id)
    cartitem.delete()
    return HttpResponseRedirect(reverse('cart_url'))



def update_cart(request, slug):
    request.session.set_expiry(12000)
    try:
        qty = session.GET.get('qty')
        update_qty = True
    except:
        qty=None
        update_qty = False

    try:
        the_id = request.session['cart_id']
    except:
        new_cart = Cart()
        new_cart.save()
        request.session['cart_id'] = new_cart.id
        the_id = new_cart.id


    cart = Cart.objects.get(id=the_id)


    try:
        product = Book.objects.get(slug=slug)
    except Book.DoesNotExist:
        pass
    except:
        pass

    cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)
    if created:
        print("yes created")

    if update_qty and qty:
        if int(qty) == 0:
            cart_item.delete()
        else:
            cart_item.quantity = qty
            cart_item.save()
    else:
        pass
    # if not cart_item in cart.items.all():
    #     cart.items.add(cart_item)
    # else:
    #     cart.items.remove(cart_item)

        return HttpResponseRedirect(reverse('cart_url'))


    # print( cart.products.count())
    return HttpResponseRedirect(reverse('cart_url'))
